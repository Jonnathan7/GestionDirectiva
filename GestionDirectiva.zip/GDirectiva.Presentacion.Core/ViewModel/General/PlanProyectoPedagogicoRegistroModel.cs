﻿using GDirectiva.Presentacion.Core.ViewModel.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDirectiva.Presentacion.Core.ViewModel.General
{
    public class PlanProyectoPedagogicoRegistroModel : GenericViewModel
    {
        public PlanProyectoPedagogicoRegistroModel()
        {

        }
    }
}
