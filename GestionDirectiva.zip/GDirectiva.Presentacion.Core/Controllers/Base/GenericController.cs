﻿//using Pe.GyM.Security.Web.Filters;
using System.Web.Mvc;

namespace GDirectiva.Presentacion.Core.Controllers.Base
{
    /// <summary>
    /// Controladora web base
    /// </summary>
    /// <remarks>
    /// Creación:       GMD 20150107
    /// Modificación:   
    /// </remarks>
    public class GenericController: Controller
    {
       
    }
}
